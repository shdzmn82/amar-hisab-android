package bd.rangdhanu.amarhisab.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

class DbConverters {
    @TypeConverter fun fromType(value: TransactionType): String = value.name
    @TypeConverter fun toType(value: String): TransactionType = TransactionType.valueOf(value)
}

@Database(entities = [Ledger::class, MoneyTransaction::class, Student::class, FeePayment::class, LoanRecord::class, BankAccount::class, BankTransfer::class, Budget::class, BudgetRule::class], version = 5, exportSchema = true)
@TypeConverters(DbConverters::class)
abstract class HisabDatabase : RoomDatabase() {
    abstract fun dao(): HisabDao

    companion object {
        @Volatile private var instance: HisabDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `students` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `roll` TEXT NOT NULL, `className` TEXT NOT NULL, `monthlyFeePaisa` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `fee_payments` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `studentId` INTEGER NOT NULL, `monthKey` TEXT NOT NULL, `amountPaisa` INTEGER NOT NULL, `paidAt` INTEGER NOT NULL)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `loans` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `personName` TEXT NOT NULL, `phone` TEXT NOT NULL, `direction` TEXT NOT NULL, `principalPaisa` INTEGER NOT NULL, `settledPaisa` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `dueAt` INTEGER NOT NULL)")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `bank_accounts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `balancePaisa` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `bank_transfers` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `bankAccountId` INTEGER NOT NULL, `direction` TEXT NOT NULL, `amountPaisa` INTEGER NOT NULL, `occurredAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `budgets` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `monthKey` TEXT NOT NULL, `category` TEXT NOT NULL, `limitPaisa` INTEGER NOT NULL)")
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `transactions` ADD COLUMN `excludeFromBudget` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("CREATE TABLE IF NOT EXISTS `budget_rules` (`category` TEXT NOT NULL, `reductionPercent` INTEGER NOT NULL, PRIMARY KEY(`category`))")
            }
        }

        fun get(context: Context): HisabDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                HisabDatabase::class.java,
                "amar_hisab.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5).build().also { instance = it }
        }
    }
}
