package bd.rangdhanu.amarhisab

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import bd.rangdhanu.amarhisab.data.DashboardSummary
import bd.rangdhanu.amarhisab.data.HisabDatabase
import bd.rangdhanu.amarhisab.data.Ledger
import bd.rangdhanu.amarhisab.data.MoneyTransaction
import bd.rangdhanu.amarhisab.data.TransactionType
import bd.rangdhanu.amarhisab.data.Student
import bd.rangdhanu.amarhisab.data.FeePayment
import bd.rangdhanu.amarhisab.data.LoanRecord
import bd.rangdhanu.amarhisab.data.BankAccount
import bd.rangdhanu.amarhisab.data.BankTransfer
import bd.rangdhanu.amarhisab.data.Budget
import bd.rangdhanu.amarhisab.data.BudgetRule
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar

class HisabViewModel(application: Application) : AndroidViewModel(application) {
    private val db = HisabDatabase.get(application)
    private val dao = db.dao()

    private val baseState = combine(dao.observeLedgers(), dao.observeTransactions(), dao.observeStudents(), dao.observeFeePayments(), dao.observeLoans()) { ledgers, transactions, students, payments, loans ->
        val ledgerOrder = listOf("PERSONAL", "SCHOOL", "COACHING", "PRIVATE_TUITION", "LOAN", "BANK")
        HisabUiState(
            ledgers = ledgers.sortedBy { ledgerOrder.indexOf(it.type).let { index -> if (index < 0) Int.MAX_VALUE else index } },
            transactions = transactions,
            students = students,
            feePayments = payments,
            loans = loans,
            summary = DashboardSummary(
                totalIncomePaisa = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPaisa },
                totalExpensePaisa = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPaisa }
            )
        )
    }

    val state = combine(baseState, dao.observeBankAccounts(), dao.observeBankTransfers(), dao.observeBudgets(), dao.observeBudgetRules()) { base, accounts, transfers, budgets, rules ->
        base.copy(bankAccounts = accounts, bankTransfers = transfers, budgets = budgets, budgetRules = rules)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HisabUiState())

    init {
        viewModelScope.launch {
            listOf(
                Ledger(name = "ব্যক্তিগত হিসাব", type = "PERSONAL"),
                Ledger(name = "রংধনু মডেল স্কুল", type = "SCHOOL"),
                Ledger(name = "কোচিং হিসাব", type = "COACHING"),
                Ledger(name = "ব্যক্তিগত প্রাইভেট", type = "PRIVATE_TUITION"),
                Ledger(name = "ধার দেওয়া ও নেওয়া", type = "LOAN"),
                Ledger(name = "ব্যাংক হিসাব", type = "BANK")
            ).forEach { ledger ->
                if (dao.ledgerCountByType(ledger.type) == 0) dao.insertLedger(ledger)
            }
        }
    }

    fun saveTransaction(id: Long, ledgerId: Long, type: TransactionType, amountPaisa: Long, category: String, note: String, occurredAt: Long, excludeFromBudget: Boolean, reductionPercent: Int) {
        if (amountPaisa <= 0 || category.isBlank()) return
        viewModelScope.launch {
            val cleanCategory = category.trim()
            val saved = MoneyTransaction(id = id, ledgerId = ledgerId, type = type, amountPaisa = amountPaisa, category = cleanCategory, note = note.trim(), occurredAt = occurredAt, excludeFromBudget = excludeFromBudget)
            dao.saveTransaction(saved)
            if (type == TransactionType.EXPENSE) {
                val rate = reductionPercent.coerceIn(0, 50)
                dao.saveBudgetRule(BudgetRule(cleanCategory, rate))
                rebuildAutoBudget(cleanCategory, rate, saved)
            }
        }
    }

    private suspend fun rebuildAutoBudget(category: String, reductionPercent: Int, pending: MoneyTransaction) {
        val end = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val start = (end.clone() as Calendar).apply { add(Calendar.MONTH, -12) }
        val source = state.value.transactions.filter { it.id != pending.id } + pending
        val history = source.filter {
            it.type == TransactionType.EXPENSE && !it.excludeFromBudget && it.category.equals(category, true) &&
                it.occurredAt >= start.timeInMillis && it.occurredAt < end.timeInMillis
        }
        val months = history.map { SimpleDateFormat("yyyy-MM", Locale.US).format(Date(it.occurredAt)) }.distinct().size
        if (months == 0) return
        val average = history.sumOf { it.amountPaisa } / months
        val limit = average * (100 - reductionPercent.coerceIn(0, 50)) / 100
        val currentMonth = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
        val existing = state.value.budgets.firstOrNull { it.monthKey == currentMonth && it.category.equals(category, true) }
        dao.saveBudget(existing?.copy(limitPaisa = limit) ?: Budget(monthKey = currentMonth, category = category, limitPaisa = limit))
    }

    fun deleteTransaction(id: Long) {
        if (id <= 0) return
        viewModelScope.launch { dao.deleteTransaction(id) }
    }

    fun saveStudent(name: String, roll: String, className: String, monthlyFeePaisa: Long) {
        if (name.isBlank() || className.isBlank() || monthlyFeePaisa <= 0) return
        viewModelScope.launch { dao.saveStudent(Student(name = name.trim(), roll = roll.trim(), className = className.trim(), monthlyFeePaisa = monthlyFeePaisa)) }
    }

    fun receiveFee(student: Student, ledgerId: Long, amountPaisa: Long) {
        if (ledgerId <= 0 || amountPaisa <= 0) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date(now))
            db.withTransaction {
                dao.insertFeePayment(FeePayment(studentId = student.id, monthKey = month, amountPaisa = amountPaisa, paidAt = now))
                dao.saveTransaction(MoneyTransaction(ledgerId = ledgerId, type = TransactionType.INCOME, amountPaisa = amountPaisa, category = "শিক্ষার্থীর ফি", note = "${student.name} • ${student.className} • রোল ${student.roll}", occurredAt = now))
            }
        }
    }

    fun saveLoan(person: String, phone: String, direction: String, amountPaisa: Long, dueAt: Long, ledgerId: Long) {
        if (person.isBlank() || amountPaisa <= 0 || ledgerId <= 0) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            db.withTransaction {
                dao.saveLoan(LoanRecord(personName = person.trim(), phone = phone.trim(), direction = direction, principalPaisa = amountPaisa, dueAt = dueAt, createdAt = now))
                dao.saveTransaction(MoneyTransaction(
                    ledgerId = ledgerId,
                    type = if (direction == "GIVEN") TransactionType.EXPENSE else TransactionType.INCOME,
                    amountPaisa = amountPaisa,
                    category = if (direction == "GIVEN") "ধার দেওয়া" else "ধার নেওয়া",
                    note = person.trim(),
                    occurredAt = now
                ))
            }
        }
    }

    fun settleLoan(loan: LoanRecord, amountPaisa: Long, ledgerId: Long) {
        val remaining = (loan.principalPaisa - loan.settledPaisa).coerceAtLeast(0)
        val accepted = amountPaisa.coerceAtMost(remaining)
        if (accepted <= 0 || ledgerId <= 0) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            db.withTransaction {
                dao.saveLoan(loan.copy(settledPaisa = loan.settledPaisa + accepted))
                dao.saveTransaction(MoneyTransaction(
                    ledgerId = ledgerId,
                    type = if (loan.direction == "GIVEN") TransactionType.INCOME else TransactionType.EXPENSE,
                    amountPaisa = accepted,
                    category = if (loan.direction == "GIVEN") "ধার ফেরত পাওয়া" else "ধার পরিশোধ",
                    note = loan.personName,
                    occurredAt = now
                ))
            }
        }
    }

    fun saveBankAccount(name: String, openingBalancePaisa: Long) {
        if (name.isBlank() || openingBalancePaisa < 0) return
        viewModelScope.launch { dao.saveBankAccount(BankAccount(name = name.trim(), balancePaisa = openingBalancePaisa)) }
    }

    fun transferBank(account: BankAccount, direction: String, amountPaisa: Long, cashLedgerId: Long) {
        if (amountPaisa <= 0 || cashLedgerId <= 0) return
        if (direction == "WITHDRAW" && amountPaisa > account.balancePaisa) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val newBalance = if (direction == "DEPOSIT") account.balancePaisa + amountPaisa else account.balancePaisa - amountPaisa
            db.withTransaction {
                dao.saveBankAccount(account.copy(balancePaisa = newBalance))
                dao.insertBankTransfer(BankTransfer(bankAccountId = account.id, direction = direction, amountPaisa = amountPaisa, occurredAt = now))
                dao.saveTransaction(MoneyTransaction(
                    ledgerId = cashLedgerId,
                    type = if (direction == "DEPOSIT") TransactionType.EXPENSE else TransactionType.INCOME,
                    amountPaisa = amountPaisa,
                    category = if (direction == "DEPOSIT") "ব্যাংকে জমা" else "ব্যাংক থেকে উত্তোলন",
                    note = account.name,
                    occurredAt = now
                ))
            }
        }
    }

    fun saveBudget(category: String, limitPaisa: Long) {
        if (category.isBlank() || limitPaisa <= 0) return
        val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
        viewModelScope.launch { dao.saveBudget(Budget(monthKey = month, category = category.trim(), limitPaisa = limitPaisa)) }
    }
}

data class HisabUiState(
    val ledgers: List<Ledger> = emptyList(),
    val transactions: List<MoneyTransaction> = emptyList(),
    val students: List<Student> = emptyList(),
    val feePayments: List<FeePayment> = emptyList(),
    val loans: List<LoanRecord> = emptyList(),
    val bankAccounts: List<BankAccount> = emptyList(),
    val bankTransfers: List<BankTransfer> = emptyList(),
    val budgets: List<Budget> = emptyList(),
    val budgetRules: List<BudgetRule> = emptyList(),
    val summary: DashboardSummary = DashboardSummary()
)
