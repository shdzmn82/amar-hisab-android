package bd.rangdhanu.amarhisab.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType { INCOME, EXPENSE }

@Entity(tableName = "ledgers")
data class Ledger(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val openingBalance: Double = 0.0
)

@Entity(tableName = "transactions")
data class MoneyTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ledgerId: Long,
    val type: TransactionType,
    val amountPaisa: Long,
    val category: String,
    val note: String,
    val occurredAt: Long = System.currentTimeMillis(),
    val excludeFromBudget: Boolean = false
)

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val roll: String,
    val className: String,
    val monthlyFeePaisa: Long
)

@Entity(tableName = "fee_payments")
data class FeePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val monthKey: String,
    val amountPaisa: Long,
    val paidAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "loans")
data class LoanRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personName: String,
    val phone: String,
    val direction: String,
    val principalPaisa: Long,
    val settledPaisa: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val dueAt: Long
)

@Entity(tableName = "bank_accounts")
data class BankAccount(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val balancePaisa: Long = 0
)

@Entity(tableName = "bank_transfers")
data class BankTransfer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bankAccountId: Long,
    val direction: String,
    val amountPaisa: Long,
    val occurredAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val monthKey: String,
    val category: String,
    val limitPaisa: Long
)

@Entity(tableName = "budget_rules")
data class BudgetRule(
    @PrimaryKey val category: String,
    val reductionPercent: Int = 15
)

data class DashboardSummary(
    val totalIncomePaisa: Long = 0,
    val totalExpensePaisa: Long = 0
) {
    val balancePaisa: Long get() = totalIncomePaisa - totalExpensePaisa
}
