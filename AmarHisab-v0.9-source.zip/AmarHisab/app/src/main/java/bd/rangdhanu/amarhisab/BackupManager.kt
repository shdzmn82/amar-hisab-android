package bd.rangdhanu.amarhisab

import android.util.Base64
import bd.rangdhanu.amarhisab.data.*
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object BackupManager {
    private const val MAGIC = "AMARHISAB-BACKUP-1"
    private const val ITERATIONS = 120_000
    private const val KEY_BITS = 256

    fun export(state: HisabUiState, password: String): ByteArray {
        require(password.length >= 4) { "পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে" }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val key = key(password, salt)
        val plain = JSONObject().apply {
            put("version", 1)
            put("createdAt", System.currentTimeMillis())
            put("ledgers", JSONArray(state.ledgers.map { JSONObject().put("id",it.id).put("name",it.name).put("type",it.type).put("openingBalance",it.openingBalance) }))
            put("transactions", JSONArray(state.transactions.map { JSONObject().put("id",it.id).put("ledgerId",it.ledgerId).put("type",it.type.name).put("amountPaisa",it.amountPaisa).put("category",it.category).put("note",it.note).put("occurredAt",it.occurredAt).put("excludeFromBudget",it.excludeFromBudget) }))
            put("students", JSONArray(state.students.map { JSONObject().put("id",it.id).put("name",it.name).put("roll",it.roll).put("className",it.className).put("monthlyFeePaisa",it.monthlyFeePaisa) }))
            put("feePayments", JSONArray(state.feePayments.map { JSONObject().put("id",it.id).put("studentId",it.studentId).put("monthKey",it.monthKey).put("amountPaisa",it.amountPaisa).put("paidAt",it.paidAt) }))
            put("loans", JSONArray(state.loans.map { JSONObject().put("id",it.id).put("personName",it.personName).put("phone",it.phone).put("direction",it.direction).put("principalPaisa",it.principalPaisa).put("settledPaisa",it.settledPaisa).put("createdAt",it.createdAt).put("dueAt",it.dueAt) }))
            put("bankAccounts", JSONArray(state.bankAccounts.map { JSONObject().put("id",it.id).put("name",it.name).put("balancePaisa",it.balancePaisa) }))
            put("bankTransfers", JSONArray(state.bankTransfers.map { JSONObject().put("id",it.id).put("bankAccountId",it.bankAccountId).put("direction",it.direction).put("amountPaisa",it.amountPaisa).put("occurredAt",it.occurredAt) }))
            put("budgets", JSONArray(state.budgets.map { JSONObject().put("id",it.id).put("monthKey",it.monthKey).put("category",it.category).put("limitPaisa",it.limitPaisa) }))
            put("budgetRules", JSONArray(state.budgetRules.map { JSONObject().put("category",it.category).put("reductionPercent",it.reductionPercent) }))
        }.toString().toByteArray(StandardCharsets.UTF_8)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(plain)
        return MAGIC.toByteArray(StandardCharsets.UTF_8) + byteArrayOf(0) + salt + iv + encrypted
    }

    fun import(bytes: ByteArray, password: String): BackupPayload {
        val magic = MAGIC.toByteArray(StandardCharsets.UTF_8)
        require(bytes.size > magic.size + 28 && bytes.copyOfRange(0, magic.size).contentEquals(magic)) { "এটি আমার হিসাবের বৈধ backup নয়" }
        var pos = magic.size + 1
        val salt = bytes.copyOfRange(pos, pos + 16); pos += 16
        val iv = bytes.copyOfRange(pos, pos + 12); pos += 12
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv))
        val root = JSONObject(String(cipher.doFinal(bytes.copyOfRange(pos, bytes.size)), StandardCharsets.UTF_8))
        require(root.optInt("version") == 1) { "Backup version সমর্থিত নয়" }
        fun arr(name: String) = root.optJSONArray(name) ?: JSONArray()
        val ledgers = arr("ledgers").toList { Ledger(it.getLong("id"),it.getString("name"),it.getString("type"),it.optDouble("openingBalance",0.0)) }
        val transactions = arr("transactions").toList { MoneyTransaction(it.getLong("id"),it.getLong("ledgerId"),TransactionType.valueOf(it.getString("type")),it.getLong("amountPaisa"),it.getString("category"),it.getString("note"),it.getLong("occurredAt"),it.optBoolean("excludeFromBudget",false)) }
        val students = arr("students").toList { Student(it.getLong("id"),it.getString("name"),it.getString("roll"),it.getString("className"),it.getLong("monthlyFeePaisa")) }
        val fees = arr("feePayments").toList { FeePayment(it.getLong("id"),it.getLong("studentId"),it.getString("monthKey"),it.getLong("amountPaisa"),it.getLong("paidAt")) }
        val loans = arr("loans").toList { LoanRecord(it.getLong("id"),it.getString("personName"),it.getString("phone"),it.getString("direction"),it.getLong("principalPaisa"),it.getLong("settledPaisa"),it.getLong("createdAt"),it.getLong("dueAt")) }
        val accounts = arr("bankAccounts").toList { BankAccount(it.getLong("id"),it.getString("name"),it.getLong("balancePaisa")) }
        val transfers = arr("bankTransfers").toList { BankTransfer(it.getLong("id"),it.getLong("bankAccountId"),it.getString("direction"),it.getLong("amountPaisa"),it.getLong("occurredAt")) }
        val budgets = arr("budgets").toList { Budget(it.getLong("id"),it.getString("monthKey"),it.getString("category"),it.getLong("limitPaisa")) }
        val rules = arr("budgetRules").toList { BudgetRule(it.getString("category"),it.getInt("reductionPercent")) }
        return BackupPayload(ledgers,transactions,students,fees,loans,accounts,transfers,budgets,rules)
    }

    private fun key(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_BITS)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    private inline fun <T> JSONArray.toList(mapper: (JSONObject) -> T): List<T> {
        val result = ArrayList<T>(length())
        for (i in 0 until length()) result += mapper(getJSONObject(i))
        return result
    }
}

data class BackupPayload(
    val ledgers: List<Ledger>, val transactions: List<MoneyTransaction>, val students: List<Student>,
    val fees: List<FeePayment>, val loans: List<LoanRecord>, val accounts: List<BankAccount>,
    val transfers: List<BankTransfer>, val budgets: List<Budget>, val rules: List<BudgetRule>
)
