package bd.rangdhanu.amarhisab.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HisabDao {
    @Query("SELECT * FROM ledgers ORDER BY id")
    fun observeLedgers(): Flow<List<Ledger>>

    @Query("SELECT * FROM transactions ORDER BY occurredAt DESC")
    fun observeTransactions(): Flow<List<MoneyTransaction>>

    @Query("SELECT * FROM students ORDER BY className, roll, name")
    fun observeStudents(): Flow<List<Student>>

    @Query("SELECT * FROM fee_payments ORDER BY paidAt DESC")
    fun observeFeePayments(): Flow<List<FeePayment>>

    @Query("SELECT * FROM loans ORDER BY dueAt, createdAt DESC")
    fun observeLoans(): Flow<List<LoanRecord>>

    @Query("SELECT * FROM bank_accounts ORDER BY name")
    fun observeBankAccounts(): Flow<List<BankAccount>>

    @Query("SELECT * FROM bank_transfers ORDER BY occurredAt DESC")
    fun observeBankTransfers(): Flow<List<BankTransfer>>

    @Query("SELECT * FROM budgets ORDER BY category")
    fun observeBudgets(): Flow<List<Budget>>

    @Query("SELECT * FROM budget_rules ORDER BY category")
    fun observeBudgetRules(): Flow<List<BudgetRule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedger(ledger: Ledger): Long

    @Insert
    suspend fun insertTransaction(transaction: MoneyTransaction)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveTransaction(transaction: MoneyTransaction)

    @Query("DELETE FROM transactions WHERE id = :transactionId")
    suspend fun deleteTransaction(transactionId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveStudent(student: Student): Long

    @Insert
    suspend fun insertFeePayment(payment: FeePayment)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLoan(loan: LoanRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveBankAccount(account: BankAccount): Long

    @Insert
    suspend fun insertBankTransfer(transfer: BankTransfer)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveBudget(budget: Budget): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveBudgetRule(rule: BudgetRule)

    @Query("DELETE FROM fee_payments") suspend fun clearFeePayments()
    @Query("DELETE FROM students") suspend fun clearStudents()
    @Query("DELETE FROM loans") suspend fun clearLoans()
    @Query("DELETE FROM bank_transfers") suspend fun clearBankTransfers()
    @Query("DELETE FROM bank_accounts") suspend fun clearBankAccounts()
    @Query("DELETE FROM budgets") suspend fun clearBudgets()
    @Query("DELETE FROM budget_rules") suspend fun clearBudgetRules()
    @Query("DELETE FROM transactions") suspend fun clearTransactions()
    @Query("DELETE FROM ledgers") suspend fun clearLedgers()

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLedgers(items: List<Ledger>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertTransactions(items: List<MoneyTransaction>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertStudents(items: List<Student>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertFeePayments(items: List<FeePayment>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLoans(items: List<LoanRecord>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertBankAccounts(items: List<BankAccount>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertBankTransfers(items: List<BankTransfer>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertBudgets(items: List<Budget>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertBudgetRules(items: List<BudgetRule>)

    @Query("SELECT COUNT(*) FROM ledgers")
    suspend fun ledgerCount(): Int

    @Query("SELECT COUNT(*) FROM ledgers WHERE type = :type")
    suspend fun ledgerCountByType(type: String): Int
}
