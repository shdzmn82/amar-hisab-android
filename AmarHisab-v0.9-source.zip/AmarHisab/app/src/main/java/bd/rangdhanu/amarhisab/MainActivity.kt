package bd.rangdhanu.amarhisab

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import bd.rangdhanu.amarhisab.data.Ledger
import bd.rangdhanu.amarhisab.data.MoneyTransaction
import bd.rangdhanu.amarhisab.data.TransactionType
import bd.rangdhanu.amarhisab.data.Student
import bd.rangdhanu.amarhisab.data.LoanRecord
import bd.rangdhanu.amarhisab.data.BankAccount
import bd.rangdhanu.amarhisab.data.Budget
import bd.rangdhanu.amarhisab.data.BudgetRule
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF176B50), background = Color(0xFFF6FBF8))) {
                HisabApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HisabApp(vm: HisabViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<MoneyTransaction?>(null) }
    var showEntry by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<MoneyTransaction?>(null) }
    var selectedLedgerId by remember { mutableStateOf<Long?>(null) }
    var showStudentDialog by remember { mutableStateOf(false) }
    var payingStudent by remember { mutableStateOf<Student?>(null) }
    var page by remember { mutableStateOf("HOME") }
    var studentQuery by remember { mutableStateOf("") }
    var showLoanDialog by remember { mutableStateOf(false) }
    var settlingLoan by remember { mutableStateOf<LoanRecord?>(null) }
    var showBankDialog by remember { mutableStateOf(false) }
    var transferAccount by remember { mutableStateOf<BankAccount?>(null) }
    var showBudgetDialog by remember { mutableStateOf(false) }
    var passwordDialog by remember { mutableStateOf<String?>(null) }
    var pendingBackupBytes by remember { mutableStateOf<ByteArray?>(null) }
    var backupPassword by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val createDocument = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        try {
            when (passwordDialog) {
                "CSV" -> contentResolver.openOutputStream(uri)?.use { it.write(csvText(state).toByteArray(Charsets.UTF_8)) }
                "PDF" -> contentResolver.openOutputStream(uri)?.use { it.write(pdfBytes(state)) }
                "BACKUP" -> contentResolver.openOutputStream(uri)?.use { it.write(BackupManager.export(state, backupPassword)) }
            }
            statusMessage = "ফাইল সফলভাবে সংরক্ষণ হয়েছে।"
        } catch (e: Exception) { statusMessage = "ফাইল সংরক্ষণ করা যায়নি: ${e.message}" }
        passwordDialog = null; pendingBackupBytes = null
    }
    val openDocument = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        try { pendingBackupBytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            passwordDialog = "RESTORE"
        } catch (e: Exception) { statusMessage = "Backup পড়া যায়নি: ${e.message}" }
    }

    val currentMonthEntries = state.transactions.filter { isCurrentMonth(it.occurredAt) }
    val monthIncome = currentMonthEntries.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPaisa }
    val monthExpense = currentMonthEntries.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPaisa }
    val visibleTransactions = selectedLedgerId?.let { id -> state.transactions.filter { it.ledgerId == id } } ?: state.transactions
    val visibleStudents = state.students.filter {
        studentQuery.isBlank() || it.name.contains(studentQuery, true) ||
            it.roll.contains(studentQuery, true) || it.className.contains(studentQuery, true)
    }
    val expectedFee = state.students.sumOf { it.monthlyFeePaisa }
    val collectedFee = state.feePayments.filter { it.monthKey == monthKey() }.sumOf { it.amountPaisa }

    Scaffold(
        topBar = { TopAppBar(title = { Text("আমার হিসাব", fontWeight = FontWeight.Bold) }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    when (page) {
                        "FEES" -> showStudentDialog = true
                        "LOANS" -> showLoanDialog = true
                        "BANK_BUDGET" -> showBankDialog = true
                        "REPORT_BACKUP" -> { }
                        else -> { editing = null; showEntry = true }
                    }
                },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text(when (page) { "FEES" -> "শিক্ষার্থী"; "LOANS" -> "নতুন ধার"; "BANK_BUDGET" -> "ব্যাংক"; else -> "নতুন এন্ট্রি" }) }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PageSelector(page) { page = it } }

            if (page == "HOME") {
                item { SummaryCard(state.summary.balancePaisa + state.bankAccounts.sumOf { it.balancePaisa }, monthIncome, monthExpense) }
                item { Heading("হিসাবখাতা") }
                items(state.ledgers, key = { it.id }) { ledger ->
                    val entries = state.transactions.filter { it.ledgerId == ledger.id }
                    val balance = entries.sumOf { if (it.type == TransactionType.INCOME) it.amountPaisa else -it.amountPaisa }
                    LedgerCard(ledger, balance, entries.size, selectedLedgerId == ledger.id) {
                        selectedLedgerId = if (selectedLedgerId == ledger.id) null else ledger.id
                        page = "TRANSACTIONS"
                    }
                }
            }

            if (page == "FEES") {
                item { FeeSummaryCard(expectedFee, collectedFee, (expectedFee - collectedFee).coerceAtLeast(0)) }
                item {
                    OutlinedTextField(
                        value = studentQuery,
                        onValueChange = { studentQuery = it },
                        label = { Text("নাম, রোল বা শ্রেণি দিয়ে খুঁজুন") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Heading("শিক্ষার্থী ফি")
                        TextButton(onClick = { showStudentDialog = true }) { Text("+ শিক্ষার্থী") }
                    }
                }
                if (visibleStudents.isEmpty()) item { Text("কোনো শিক্ষার্থী পাওয়া যায়নি।") }
                items(visibleStudents, key = { "student-${it.id}" }) { student ->
                    val paid = state.feePayments.filter { it.studentId == student.id && it.monthKey == monthKey() }.sumOf { it.amountPaisa }
                    StudentCard(student, paid, (student.monthlyFeePaisa - paid).coerceAtLeast(0)) { payingStudent = student }
                }
            }

            if (page == "TRANSACTIONS") {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Heading(selectedLedgerId?.let { id -> state.ledgers.firstOrNull { it.id == id }?.name } ?: "সকল লেনদেন")
                        if (selectedLedgerId != null) TextButton(onClick = { selectedLedgerId = null }) { Text("সব দেখুন") }
                    }
                }
                if (visibleTransactions.isEmpty()) item { Text("এই হিসাবখাতায় কোনো লেনদেন নেই।") }
                items(visibleTransactions.take(100), key = { it.id }) { tx ->
                    TransactionCard(
                        tx,
                        state.ledgers.firstOrNull { it.id == tx.ledgerId }?.name ?: "হিসাবখাতা",
                        onEdit = { editing = tx; showEntry = true },
                        onDelete = { deleting = tx }
                    )
                }
            }

            if (page == "LOANS") {
                val receivable = state.loans.filter { it.direction == "GIVEN" }.sumOf { (it.principalPaisa - it.settledPaisa).coerceAtLeast(0) }
                val payable = state.loans.filter { it.direction == "TAKEN" }.sumOf { (it.principalPaisa - it.settledPaisa).coerceAtLeast(0) }
                item { LoanSummaryCard(receivable, payable) }
                item { Heading("ধার দেওয়া ও নেওয়া") }
                if (state.loans.isEmpty()) item { Text("এখনও কোনো ধার-পাওনার রেকর্ড নেই।") }
                items(state.loans, key = { "loan-${it.id}" }) { loan ->
                    LoanCard(loan) { settlingLoan = loan }
                }
            }

            if (page == "REPORT_BACKUP") {
                item { Heading("রিপোর্ট ও Backup") }
                item { Text("ডেটা CSV/PDF হিসেবে বের করুন এবং encrypted backup তৈরি বা restore করুন।") }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { passwordDialog = "CSV"; createDocument.launch("amar-hisab-${monthKey()}.csv") }) { Text("CSV Export") }
                        Button(onClick = { passwordDialog = "PDF"; createDocument.launch("amar-hisab-${monthKey()}.pdf") }) { Text("PDF Export") }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { backupPassword = ""; passwordDialog = "BACKUP" }) { Text("Backup তৈরি") }
                        OutlinedButton(onClick = { openDocument.launch(arrayOf("application/octet-stream", "*/*")) }) { Text("Backup Restore") }
                    }
                }
                item { Text("Backup password ছাড়া খোলা যাবে না। Restore করলে বর্তমান ডেটা সম্পূর্ণভাবে backup-এর ডেটা দিয়ে প্রতিস্থাপিত হবে।", style = MaterialTheme.typography.bodySmall) }
            }

            if (page == "BANK_BUDGET") {
                item { BankSummaryCard(state.bankAccounts.sumOf { it.balancePaisa }) }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Heading("ব্যাংক হিসাব")
                        TextButton(onClick = { showBankDialog = true }) { Text("+ ব্যাংক") }
                    }
                }
                if (state.bankAccounts.isEmpty()) item { Text("এখনও কোনো ব্যাংক হিসাব যোগ করা হয়নি।") }
                items(state.bankAccounts, key = { "bank-${it.id}" }) { account -> BankCard(account) { transferAccount = account } }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Heading("চলতি মাসের বাজেট")
                        TextButton(onClick = { showBudgetDialog = true }) { Text("+ বাজেট") }
                    }
                }
                if (state.budgets.none { it.monthKey == monthKey() }) item { Text("চলতি মাসের কোনো বাজেট নির্ধারণ করা হয়নি।") }
                items(state.budgets.filter { it.monthKey == monthKey() }, key = { "budget-${it.id}" }) { budget ->
                    val spent = currentMonthEntries.filter { it.type == TransactionType.EXPENSE && !it.excludeFromBudget && it.category.equals(budget.category, true) }.sumOf { it.amountPaisa }
                    BudgetCard(budget.category, budget.limitPaisa, spent)
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }

    if (showEntry && state.ledgers.isNotEmpty()) {
        EntryDialog(state.ledgers, state.transactions, state.budgets, state.budgetRules, editing, onDismiss = { showEntry = false; editing = null }) {
                id, ledgerId, type, amount, category, note, date, excluded, reduction ->
            vm.saveTransaction(id, ledgerId, type, amount, category, note, date, excluded, reduction)
            showEntry = false
            editing = null
        }
    }

    if (showStudentDialog) {
        StudentDialog(onDismiss = { showStudentDialog = false }) { name, roll, className, fee ->
            vm.saveStudent(name, roll, className, fee)
            showStudentDialog = false
        }
    }

    payingStudent?.let { student ->
        val paid = state.feePayments.filter { it.studentId == student.id && it.monthKey == monthKey() }.sumOf { it.amountPaisa }
        val due = (student.monthlyFeePaisa - paid).coerceAtLeast(0)
        FeeDialog(student, due, state.ledgers, onDismiss = { payingStudent = null }) { ledgerId, amount ->
            vm.receiveFee(student, ledgerId, amount)
            payingStudent = null
        }
    }

    if (showLoanDialog && state.ledgers.isNotEmpty()) {
        LoanDialog(state.ledgers, onDismiss = { showLoanDialog = false }) { person, phone, direction, amount, dueAt, ledgerId ->
            vm.saveLoan(person, phone, direction, amount, dueAt, ledgerId)
            showLoanDialog = false
        }
    }

    settlingLoan?.let { loan ->
        SettlementDialog(loan, state.ledgers, onDismiss = { settlingLoan = null }) { amount, ledgerId ->
            vm.settleLoan(loan, amount, ledgerId)
            settlingLoan = null
        }
    }

    if (showBankDialog) {
        BankDialog(onDismiss = { showBankDialog = false }) { name, balance ->
            vm.saveBankAccount(name, balance); showBankDialog = false
        }
    }

    transferAccount?.let { account ->
        BankTransferDialog(account, state.ledgers, onDismiss = { transferAccount = null }) { direction, amount, ledgerId ->
            vm.transferBank(account, direction, amount, ledgerId); transferAccount = null
        }
    }

    if (showBudgetDialog) {
        BudgetDialog(onDismiss = { showBudgetDialog = false }) { category, limit ->
            vm.saveBudget(category, limit); showBudgetDialog = false
        }
    }

    deleting?.let { tx ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("লেনদেন মুছবেন?") },
            text = { Text("${tx.category} — ${money(tx.amountPaisa)} স্থায়ীভাবে মুছে যাবে।") },
            confirmButton = {
                TextButton(onClick = { vm.deleteTransaction(tx.id); deleting = null }) {
                    Text("মুছুন", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("বাতিল") } }
        )
    }

    if (passwordDialog == "BACKUP") {
        PasswordDialog("Backup password", backupPassword, { backupPassword = it }, onDismiss = { passwordDialog = null }, onConfirm = {
            try {
                // Validate before opening the save picker.
                BackupManager.export(state, backupPassword)
                createDocument.launch("amar-hisab-${monthKey()}.ahb")
            } catch (e: Exception) { statusMessage = e.message }
        })
    }
    if (passwordDialog == "RESTORE" && pendingBackupBytes != null) {
        PasswordDialog("Restore password", backupPassword, { backupPassword = it }, onDismiss = { passwordDialog = null; pendingBackupBytes = null }, onConfirm = {
            try {
                val payload = BackupManager.import(pendingBackupBytes!!, backupPassword)
                vm.restoreBackup(payload)
                statusMessage = "Backup restore সম্পন্ন হয়েছে।"
                passwordDialog = null; pendingBackupBytes = null
            } catch (e: Exception) { statusMessage = "Restore ব্যর্থ: ${e.message}" }
        })
    }
    statusMessage?.let { msg ->
        AlertDialog(onDismissRequest = { statusMessage = null }, title = { Text("আমার হিসাব") }, text = { Text(msg) }, confirmButton = { TextButton(onClick = { statusMessage = null }) { Text("ঠিক আছে") } })
    }

}

@Composable
private fun PasswordDialog(title: String, value: String, onValue: (String) -> Unit, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { OutlinedTextField(value, onValue, label = { Text("Password") }, singleLine = true) }, confirmButton = { TextButton(onClick = onConfirm, enabled = value.length >= 4) { Text("চালু করুন") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } })
}

@Composable private fun Heading(text: String) = Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

@Composable
private fun PageSelector(page: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(selected = page == "HOME", onClick = { onSelect("HOME") }, label = { Text("হোম") })
        FilterChip(selected = page == "FEES", onClick = { onSelect("FEES") }, label = { Text("শিক্ষার্থী ফি") })
        FilterChip(selected = page == "TRANSACTIONS", onClick = { onSelect("TRANSACTIONS") }, label = { Text("লেনদেন") })
        FilterChip(selected = page == "LOANS", onClick = { onSelect("LOANS") }, label = { Text("ধার-পাওনা") })
        FilterChip(selected = page == "BANK_BUDGET", onClick = { onSelect("BANK_BUDGET") }, label = { Text("ব্যাংক-বাজেট") })
        FilterChip(selected = page == "REPORT_BACKUP", onClick = { onSelect("REPORT_BACKUP") }, label = { Text("রিপোর্ট/Backup") })
    }
}

@Composable
private fun FeeSummaryCard(expected: Long, collected: Long, due: Long) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("চলতি মাসের ফি", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("নির্ধারিত\n${money(expected)}")
                Text("আদায়\n${money(collected)}", color = Color(0xFF176B50))
                Text("বকেয়া\n${money(due)}", color = if (due > 0) Color(0xFFB3261E) else Color(0xFF176B50))
            }
        }
    }
}

@Composable
private fun LoanSummaryCard(receivable: Long, payable: Long) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("মোট পাওনা\n${money(receivable)}", color = Color(0xFF176B50), fontWeight = FontWeight.SemiBold)
            Text("মোট দেনা\n${money(payable)}", color = Color(0xFFB3261E), fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun BankSummaryCard(total: Long) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("মোট ব্যাংক ব্যালেন্স", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(money(total), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color(0xFF176B50))
        }
    }
}

@Composable
private fun BankCard(account: BankAccount, onTransfer: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text(account.name, fontWeight = FontWeight.SemiBold); Text(money(account.balancePaisa), color = Color(0xFF176B50)) }
            TextButton(onClick = onTransfer) { Text("জমা/উত্তোলন") }
        }
    }
}

@Composable
private fun BudgetCard(category: String, limit: Long, spent: Long) {
    val progress = if (limit > 0) (spent.toFloat() / limit.toFloat()).coerceIn(0f, 1f) else 0f
    val exceeded = spent > limit
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(category, fontWeight = FontWeight.SemiBold)
                Text(if (exceeded) "সীমা অতিক্রম" else "${money(spent)} / ${money(limit)}", color = if (exceeded) Color(0xFFB3261E) else MaterialTheme.colorScheme.onSurface)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = if (exceeded) Color(0xFFB3261E) else Color(0xFF176B50))
            if (exceeded) Text("অতিরিক্ত ব্যয়: ${money(spent - limit)}", color = Color(0xFFB3261E))
        }
    }
}

@Composable
private fun BankDialog(onDismiss: () -> Unit, onSave: (String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var balance by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন ব্যাংক হিসাব") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("ব্যাংক/হিসাবের নাম") }, singleLine = true)
            OutlinedTextField(balance, { balance = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("প্রারম্ভিক ব্যালেন্স") }, singleLine = true)
        } },
        confirmButton = { TextButton(onClick = { onSave(name, toPaisa(balance)) }, enabled = name.isNotBlank()) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun BankTransferDialog(account: BankAccount, ledgers: List<Ledger>, onDismiss: () -> Unit, onSave: (String, Long, Long) -> Unit) {
    var direction by remember { mutableStateOf("DEPOSIT") }
    var amount by remember { mutableStateOf("") }
    var ledgerId by remember { mutableLongStateOf(ledgers.firstOrNull { it.type == "PERSONAL" }?.id ?: ledgers.first().id) }
    var menuOpen by remember { mutableStateOf(false) }
    val valid = toPaisa(amount) > 0 && (direction == "DEPOSIT" || toPaisa(amount) <= account.balancePaisa)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(account.name) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("বর্তমান ব্যালেন্স: ${money(account.balancePaisa)}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(direction == "DEPOSIT", { direction = "DEPOSIT" }, label = { Text("ব্যাংকে জমা") })
                FilterChip(direction == "WITHDRAW", { direction = "WITHDRAW" }, label = { Text("উত্তোলন") })
            }
            OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("পরিমাণ") }, singleLine = true)
            Box {
                OutlinedButton({ menuOpen = true }, Modifier.fillMaxWidth()) { Text("নগদ খাতা: ${ledgers.first { it.id == ledgerId }.name}") }
                DropdownMenu(menuOpen, { menuOpen = false }) { ledgers.filter { it.type != "BANK" }.forEach { l -> DropdownMenuItem({ Text(l.name) }, { ledgerId = l.id; menuOpen = false }) } }
            }
        } },
        confirmButton = { TextButton(onClick = { onSave(direction, toPaisa(amount), ledgerId) }, enabled = valid) { Text("সম্পন্ন করুন") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun BudgetDialog(onDismiss: () -> Unit, onSave: (String, Long) -> Unit) {
    var category by remember { mutableStateOf("") }
    var limit by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("মাসিক বাজেট") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(category, { category = it }, label = { Text("ব্যয়ের ক্যাটাগরি") }, singleLine = true)
            OutlinedTextField(limit, { limit = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("ব্যয়সীমা") }, singleLine = true)
            Text("ক্যাটাগরির বানান আয়–ব্যয় এন্ট্রির সঙ্গে একই রাখুন।", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = { onSave(category, toPaisa(limit)) }, enabled = category.isNotBlank() && toPaisa(limit) > 0) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun LoanCard(loan: LoanRecord, onSettle: () -> Unit) {
    val remaining = (loan.principalPaisa - loan.settledPaisa).coerceAtLeast(0)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(loan.personName, fontWeight = FontWeight.SemiBold)
                Text(if (loan.direction == "GIVEN") "পাওনা" else "দেনা", color = if (loan.direction == "GIVEN") Color(0xFF176B50) else Color(0xFFB3261E))
            }
            if (loan.phone.isNotBlank()) Text("ফোন: ${loan.phone}")
            Text("মূল: ${money(loan.principalPaisa)} • বাকি: ${money(remaining)}")
            Text("পরিশোধের তারিখ: ${dateText(loan.dueAt)}", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = onSettle, enabled = remaining > 0) { Text(if (remaining > 0) "আংশিক/পূর্ণ নিষ্পত্তি" else "নিষ্পত্তি সম্পন্ন") }
        }
    }
}

@Composable
private fun LoanDialog(
    ledgers: List<Ledger>, onDismiss: () -> Unit,
    onSave: (String, String, String, Long, Long, Long) -> Unit
) {
    val context = LocalContext.current
    var person by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf("GIVEN") }
    var amount by remember { mutableStateOf("") }
    var dueAt by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var ledgerId by remember { mutableLongStateOf(ledgers.firstOrNull { it.type == "LOAN" }?.id ?: ledgers.first().id) }
    var menuOpen by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন ধার-পাওনা") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(direction == "GIVEN", { direction = "GIVEN" }, label = { Text("ধার দিয়েছি") })
                FilterChip(direction == "TAKEN", { direction = "TAKEN" }, label = { Text("ধার নিয়েছি") })
            }
            OutlinedTextField(person, { person = it }, label = { Text("ব্যক্তির নাম") }, singleLine = true)
            OutlinedTextField(phone, { phone = it.filter { ch -> ch.isDigit() || ch == '+' } }, label = { Text("ফোন (ঐচ্ছিক)") }, singleLine = true)
            OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("পরিমাণ") }, singleLine = true)
            OutlinedButton(onClick = {
                val cal = Calendar.getInstance().apply { timeInMillis = dueAt }
                DatePickerDialog(context, { _, y, m, d -> dueAt = Calendar.getInstance().apply { set(y, m, d, 12, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
            }, modifier = Modifier.fillMaxWidth()) { Text("পরিশোধের তারিখ: ${dateText(dueAt)}") }
            Box {
                OutlinedButton({ menuOpen = true }, Modifier.fillMaxWidth()) { Text(ledgers.first { it.id == ledgerId }.name) }
                DropdownMenu(menuOpen, { menuOpen = false }) { ledgers.forEach { l -> DropdownMenuItem({ Text(l.name) }, { ledgerId = l.id; menuOpen = false }) } }
            }
        } },
        confirmButton = { TextButton(onClick = { onSave(person, phone, direction, toPaisa(amount), dueAt, ledgerId) }, enabled = person.isNotBlank() && toPaisa(amount) > 0) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun SettlementDialog(loan: LoanRecord, ledgers: List<Ledger>, onDismiss: () -> Unit, onSave: (Long, Long) -> Unit) {
    val remaining = (loan.principalPaisa - loan.settledPaisa).coerceAtLeast(0)
    var amount by remember(loan.id) { mutableStateOf(paisaInput(remaining)) }
    var ledgerId by remember(loan.id) { mutableLongStateOf(ledgers.firstOrNull { it.type == "LOAN" }?.id ?: ledgers.first().id) }
    var menuOpen by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (loan.direction == "GIVEN") "ফেরত গ্রহণ" else "ধার পরিশোধ") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${loan.personName} • বাকি ${money(remaining)}")
            OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("পরিমাণ") }, singleLine = true)
            Box {
                OutlinedButton({ menuOpen = true }, Modifier.fillMaxWidth()) { Text(ledgers.first { it.id == ledgerId }.name) }
                DropdownMenu(menuOpen, { menuOpen = false }) { ledgers.forEach { l -> DropdownMenuItem({ Text(l.name) }, { ledgerId = l.id; menuOpen = false }) } }
            }
        } },
        confirmButton = { TextButton(onClick = { onSave(toPaisa(amount), ledgerId) }, enabled = toPaisa(amount) in 1..remaining) { Text("নিষ্পত্তি করুন") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun SummaryCard(balance: Long, monthIncome: Long, monthExpense: Long) {
    Card(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("সর্বমোট বর্তমান ব্যালেন্স", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(money(balance), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("এই মাসের আয়\n${money(monthIncome)}", color = Color(0xFF176B50))
                Text("এই মাসের ব্যয়\n${money(monthExpense)}", color = Color(0xFFB3261E))
            }
        }
    }
}

@Composable
private fun LedgerCard(ledger: Ledger, balance: Long, count: Int, selected: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(
        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    )) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(ledger.name, fontWeight = FontWeight.SemiBold)
                Text("$count টি লেনদেন", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(money(balance), fontWeight = FontWeight.Bold, color = if (balance >= 0) Color(0xFF176B50) else Color(0xFFB3261E))
        }
    }
}

@Composable
private fun TransactionCard(tx: MoneyTransaction, ledgerName: String, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(tx.category, fontWeight = FontWeight.Medium)
                Text("$ledgerName • ${dateText(tx.occurredAt)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (tx.note.isNotBlank()) Text(tx.note)
                if (tx.excludeFromBudget) Text("এককালীন ব্যয় • বাজেটের বাইরে", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
            }
            Column {
                Text(
                    (if (tx.type == TransactionType.INCOME) "+ " else "− ") + money(tx.amountPaisa),
                    color = if (tx.type == TransactionType.INCOME) Color(0xFF176B50) else Color(0xFFB3261E),
                    fontWeight = FontWeight.SemiBold
                )
                Row {
                    IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "সম্পাদনা") }
                    IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "মুছুন", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
}

@Composable
private fun StudentCard(student: Student, paid: Long, due: Long, onPay: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(student.name, fontWeight = FontWeight.SemiBold)
                    Text("${student.className} • রোল ${student.roll}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("বকেয়া ${money(due)}", color = if (due > 0) Color(0xFFB3261E) else Color(0xFF176B50))
            }
            Text("এই মাসে পরিশোধ: ${money(paid)} / ${money(student.monthlyFeePaisa)}")
            TextButton(onClick = onPay, enabled = due > 0) { Text(if (due > 0) "ফি গ্রহণ" else "পরিশোধ সম্পন্ন") }
        }
    }
}

@Composable
private fun StudentDialog(onDismiss: () -> Unit, onSave: (String, String, String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var roll by remember { mutableStateOf("") }
    var className by remember { mutableStateOf("") }
    var fee by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন শিক্ষার্থী") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("শিক্ষার্থীর নাম") }, singleLine = true)
            OutlinedTextField(roll, { roll = it }, label = { Text("রোল") }, singleLine = true)
            OutlinedTextField(className, { className = it }, label = { Text("শ্রেণি/ব্যাচ") }, singleLine = true)
            OutlinedTextField(fee, { fee = it.filter(Char::isDigit) }, label = { Text("মাসিক ফি") }, singleLine = true)
        } },
        confirmButton = { TextButton(onClick = { onSave(name, roll, className, toPaisa(fee)) }, enabled = name.isNotBlank() && className.isNotBlank() && toPaisa(fee) > 0) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun FeeDialog(student: Student, duePaisa: Long, ledgers: List<Ledger>, onDismiss: () -> Unit, onSave: (Long, Long) -> Unit) {
    var amount by remember(student.id, duePaisa) { mutableStateOf(paisaInput(duePaisa)) }
    var ledgerId by remember(student.id) { mutableLongStateOf(ledgers.firstOrNull { it.type == "SCHOOL" }?.id ?: ledgers.first().id) }
    var menuOpen by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${student.name}—ফি গ্রহণ") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("পরিমাণ") }, singleLine = true)
            Box {
                OutlinedButton({ menuOpen = true }, Modifier.fillMaxWidth()) { Text(ledgers.first { it.id == ledgerId }.name) }
                DropdownMenu(menuOpen, { menuOpen = false }) {
                    ledgers.forEach { ledger -> DropdownMenuItem({ Text(ledger.name) }, { ledgerId = ledger.id; menuOpen = false }) }
                }
            }
            Text("ফি গ্রহণ করলে একই পরিমাণ নির্বাচিত হিসাবখাতায় আয় হিসেবে যোগ হবে।", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = { onSave(ledgerId, toPaisa(amount)) }, enabled = toPaisa(amount) > 0) { Text("ফি গ্রহণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun EntryDialog(
    ledgers: List<Ledger>, transactions: List<MoneyTransaction>, budgets: List<Budget>, rules: List<BudgetRule>,
    existing: MoneyTransaction?, onDismiss: () -> Unit,
    onSave: (Long, Long, TransactionType, Long, String, String, Long, Boolean, Int) -> Unit
) {
    val context = LocalContext.current
    var ledgerId by remember(existing?.id) { mutableLongStateOf(existing?.ledgerId ?: ledgers.first().id) }
    var amount by remember(existing?.id) { mutableStateOf(existing?.let { paisaInput(it.amountPaisa) } ?: "") }
    var category by remember(existing?.id) { mutableStateOf(existing?.category ?: "") }
    var note by remember(existing?.id) { mutableStateOf(existing?.note ?: "") }
    var type by remember(existing?.id) { mutableStateOf(existing?.type ?: TransactionType.EXPENSE) }
    var occurredAt by remember(existing?.id) { mutableLongStateOf(existing?.occurredAt ?: System.currentTimeMillis()) }
    var menuOpen by remember { mutableStateOf(false) }
    var excluded by remember(existing?.id) { mutableStateOf(existing?.excludeFromBudget ?: false) }
    var reduction by remember(existing?.id) { mutableStateOf("15") }
    val categories = if (type == TransactionType.INCOME)
        listOf("বেতন", "শিক্ষার্থীর ফি", "কোচিং ফি", "ব্যবসা", "উপহার", "অন্যান্য আয়")
    else listOf("বাজার", "যাতায়াত", "শিক্ষা", "চিকিৎসা", "বেতন", "বিল", "অন্যান্য ব্যয়")
    val rate = reduction.toIntOrNull()?.coerceIn(0, 50) ?: 15
    val automaticBudget = automaticBudgetPreview(category, transactions, rate)
    val currentBudget = budgets.firstOrNull { it.monthKey == monthKey() && it.category.equals(category, true) }?.limitPaisa ?: automaticBudget
    val spentThisMonth = transactions.filter {
        it.type == TransactionType.EXPENSE && !it.excludeFromBudget && isCurrentMonth(it.occurredAt) && it.category.equals(category, true)
    }.sumOf { it.amountPaisa }
    val remaining = (currentBudget - spentThisMonth).coerceAtLeast(0)

    LaunchedEffect(category) {
        reduction = rules.firstOrNull { it.category.equals(category, true) }
            ?.reductionPercent?.toString() ?: "15"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "নতুন আয়–ব্যয়" else "লেনদেন সম্পাদনা") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == TransactionType.INCOME, { type = TransactionType.INCOME; category = "" }, label = { Text("আয়") })
                    FilterChip(type == TransactionType.EXPENSE, { type = TransactionType.EXPENSE; category = "" }, label = { Text("ব্যয়") })
                }
                Box {
                    OutlinedButton({ menuOpen = true }, Modifier.fillMaxWidth()) {
                        Text(ledgers.firstOrNull { it.id == ledgerId }?.name ?: "হিসাবখাতা নির্বাচন")
                    }
                    DropdownMenu(menuOpen, { menuOpen = false }) {
                        ledgers.forEach { ledger ->
                            DropdownMenuItem({ Text(ledger.name) }, { ledgerId = ledger.id; menuOpen = false })
                        }
                    }
                }
                OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("পরিমাণ") }, singleLine = true)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    categories.forEach { item -> FilterChip(category == item, { category = item }, label = { Text(item) }) }
                }
                OutlinedTextField(category, { category = it }, label = { Text("খাত/ক্যাটাগরি") }, singleLine = true)
                if (type == TransactionType.EXPENSE && category.isNotBlank()) {
                    OutlinedTextField(
                        reduction,
                        { reduction = it.filter(Char::isDigit).take(2) },
                        label = { Text("ব্যয় সংকোচন (%)") },
                        supportingText = { Text("০–৫০ শতাংশ") },
                        singleLine = true
                    )
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(10.dp)) {
                            Text("মাসিক বাজেট: ${money(currentBudget)}")
                            Text("এ মাসে ব্যয়: ${money(spentThisMonth)}")
                            Text("এখন ব্যয়যোগ্য: ${money(remaining)}", fontWeight = FontWeight.SemiBold)
                            val projected = remaining - toPaisa(amount)
                            if (projected < 0) Text("এই এন্ট্রির পর সীমা ছাড়াবে: ${money(-projected)}", color = MaterialTheme.colorScheme.error)
                        }
                    }
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Checkbox(checked = excluded, onCheckedChange = { excluded = it })
                        Text("এককালীন/অস্বাভাবিক—বাজেট গণনা থেকে বাদ")
                    }
                }
                OutlinedButton(onClick = {
                    val cal = Calendar.getInstance().apply { timeInMillis = occurredAt }
                    DatePickerDialog(context, { _, y, m, d ->
                        occurredAt = Calendar.getInstance().apply {
                            set(y, m, d, 12, 0, 0); set(Calendar.MILLISECOND, 0)
                        }.timeInMillis
                    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                }, modifier = Modifier.fillMaxWidth()) { Text("তারিখ: ${dateText(occurredAt)}") }
                OutlinedTextField(note, { note = it }, label = { Text("বিবরণ (ঐচ্ছিক)") })
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(existing?.id ?: 0, ledgerId, type, toPaisa(amount), category, note, occurredAt, excluded, rate) },
                enabled = toPaisa(amount) > 0 && category.isNotBlank()
            ) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

private fun toPaisa(value: String): Long = try {
    BigDecimal(value).multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
} catch (_: Exception) { 0 }

private fun paisaInput(paisa: Long) = BigDecimal(paisa).divide(BigDecimal(100)).stripTrailingZeros().toPlainString()

private fun money(paisa: Long): String = "৳" + NumberFormat.getNumberInstance(Locale("en", "BD")).format(BigDecimal(paisa).divide(BigDecimal(100)))

private fun dateText(timestamp: Long): String = SimpleDateFormat("dd MMM yyyy", Locale("bn", "BD")).format(Date(timestamp))

private fun isCurrentMonth(timestamp: Long): Boolean {
    val now = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = timestamp }
    return now.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
        now.get(Calendar.MONTH) == date.get(Calendar.MONTH)
}

private fun monthKey(): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())

private fun automaticBudgetPreview(category: String, transactions: List<MoneyTransaction>, reductionPercent: Int): Long {
    if (category.isBlank()) return 0
    val end = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    val start = (end.clone() as Calendar).apply { add(Calendar.MONTH, -12) }
    val history = transactions.filter {
        it.type == TransactionType.EXPENSE && !it.excludeFromBudget && it.category.equals(category, true) &&
            it.occurredAt >= start.timeInMillis && it.occurredAt < end.timeInMillis
    }
    val months = history.map { SimpleDateFormat("yyyy-MM", Locale.US).format(Date(it.occurredAt)) }.distinct().size
    if (months == 0) return 0
    val average = history.sumOf { it.amountPaisa } / months
    return average * (100 - reductionPercent.coerceIn(0, 50)) / 100
}


private fun csvEscape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

private fun csvText(state: HisabUiState): String = buildString {
    append('\uFEFF')
    appendLine("তারিখ,ধরন,হিসাবখাতা,ক্যাটাগরি,পরিমাণ,বিবরণ,Budget বাদ")
    state.transactions.sortedBy { it.occurredAt }.forEach { tx ->
        val ledger = state.ledgers.firstOrNull { it.id == tx.ledgerId }?.name ?: ""
        appendLine(listOf(
            dateText(tx.occurredAt), if (tx.type == TransactionType.INCOME) "আয়" else "ব্যয়",
            ledger, tx.category, paisaInput(tx.amountPaisa), tx.note, if (tx.excludeFromBudget) "হ্যাঁ" else "না"
        ).joinToString(",") { csvEscape(it) })
    }
}

private fun pdfBytes(state: HisabUiState): ByteArray {
    val pdf = android.graphics.pdf.PdfDocument()
    val paint = android.graphics.Paint().apply { textSize = 11f }
    val titlePaint = android.graphics.Paint().apply { textSize = 18f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
    val pageWidth = 595
    val pageHeight = 842
    var pageNo = 1
    var docPage = pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
    var canvas = docPage.canvas
    var y = 36f
    canvas.drawText("আমার হিসাব — লেনদেন রিপোর্ট", 24f, y, titlePaint); y += 26f
    canvas.drawText("মোট লেনদেন: ${state.transactions.size}", 24f, y, paint); y += 22f
    state.transactions.sortedBy { it.occurredAt }.forEach { tx ->
        if (y > pageHeight - 30) {
            pdf.finishPage(docPage); pageNo++
            docPage = pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
            canvas = docPage.canvas; y = 36f
        }
        val ledger = state.ledgers.firstOrNull { it.id == tx.ledgerId }?.name ?: ""
        val line = "${dateText(tx.occurredAt)} | ${if (tx.type == TransactionType.INCOME) "আয়" else "ব্যয়"} | ${tx.category} | ${money(tx.amountPaisa)} | $ledger"
        canvas.drawText(line.take(105), 24f, y, paint); y += 16f
    }
    pdf.finishPage(docPage)
    val out = java.io.ByteArrayOutputStream(); pdf.writeTo(out); pdf.close(); return out.toByteArray()
}
