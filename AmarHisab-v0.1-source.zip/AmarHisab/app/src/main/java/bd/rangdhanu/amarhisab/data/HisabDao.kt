package bd.rangdhanu.amarhisab.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HisabDao {
    @Query("SELECT * FROM ledgers ORDER BY id")
    fun observeLedgers(): Flow<List<Ledger>>

    @Query("SELECT * FROM transactions ORDER BY occurredAt DESC")
    fun observeTransactions(): Flow<List<MoneyTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedger(ledger: Ledger): Long

    @Insert
    suspend fun insertTransaction(transaction: MoneyTransaction)

    @Query("SELECT COUNT(*) FROM ledgers")
    suspend fun ledgerCount(): Int
}
