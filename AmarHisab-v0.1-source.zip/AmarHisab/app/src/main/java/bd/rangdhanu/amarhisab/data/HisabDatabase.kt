package bd.rangdhanu.amarhisab.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class DbConverters {
    @TypeConverter fun fromType(value: TransactionType): String = value.name
    @TypeConverter fun toType(value: String): TransactionType = TransactionType.valueOf(value)
}

@Database(entities = [Ledger::class, MoneyTransaction::class], version = 1, exportSchema = true)
@TypeConverters(DbConverters::class)
abstract class HisabDatabase : RoomDatabase() {
    abstract fun dao(): HisabDao

    companion object {
        @Volatile private var instance: HisabDatabase? = null

        fun get(context: Context): HisabDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                HisabDatabase::class.java,
                "amar_hisab.db"
            ).build().also { instance = it }
        }
    }
}
