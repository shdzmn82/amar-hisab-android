package bd.rangdhanu.amarhisab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import bd.rangdhanu.amarhisab.data.TransactionType
import java.text.NumberFormat
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = lightHisabColors()) { HisabApp() } }
    }
}

@Composable
private fun lightHisabColors() = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF176B50), secondary = Color(0xFF4D6358),
    background = Color(0xFFF6FBF8), surface = Color.White
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HisabApp(vm: HisabViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var showEntry by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("আমার হিসাব", fontWeight = FontWeight.Bold) }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showEntry = true }, icon = { androidx.compose.material3.Icon(Icons.Default.Add, null) }, text = { Text("নতুন এন্ট্রি") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { SummaryCard(state.summary.totalIncomePaisa, state.summary.totalExpensePaisa, state.summary.balancePaisa) }
            item { Text("হিসাবখাতা", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(state.ledgers) { ledger ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(ledger.name, fontWeight = FontWeight.SemiBold)
                        Text("এই খাতের বিস্তারিত লেনদেন", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item { Text("সাম্প্রতিক লেনদেন", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            if (state.transactions.isEmpty()) item { Text("এখনও কোনো লেনদেন যোগ করা হয়নি।") }
            items(state.transactions.take(10)) { tx ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text(tx.category, fontWeight = FontWeight.Medium); if (tx.note.isNotBlank()) Text(tx.note) }
                        Text((if (tx.type == TransactionType.INCOME) "+ " else "− ") + money(tx.amountPaisa), color = if (tx.type == TransactionType.INCOME) Color(0xFF176B50) else Color(0xFFB3261E))
                    }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }

    if (showEntry) EntryDialog(state.ledgers.firstOrNull()?.id, onDismiss = { showEntry = false }) { ledger, type, amount, category, note ->
        vm.addTransaction(ledger, type, amount, category, note)
        showEntry = false
    }
}

@Composable
private fun SummaryCard(income: Long, expense: Long, balance: Long) {
    Card(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("বর্তমান ব্যালেন্স", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(money(balance), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("মোট আয়\n${money(income)}", color = Color(0xFF176B50))
                Text("মোট ব্যয়\n${money(expense)}", color = Color(0xFFB3261E))
            }
        }
    }
}

@Composable
private fun EntryDialog(defaultLedgerId: Long?, onDismiss: () -> Unit, onSave: (Long, TransactionType, Long, String, String) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(TransactionType.EXPENSE) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন আয়–ব্যয়") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { type = TransactionType.INCOME }, enabled = type != TransactionType.INCOME) { Text("আয়") }
                    Button(onClick = { type = TransactionType.EXPENSE }, enabled = type != TransactionType.EXPENSE) { Text("ব্যয়") }
                }
                OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("পরিমাণ") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("খাত") }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("বিবরণ (ঐচ্ছিক)") })
            }
        },
        confirmButton = { TextButton(onClick = { defaultLedgerId?.let { onSave(it, type, toPaisa(amount), category, note) } }, enabled = defaultLedgerId != null && toPaisa(amount) > 0 && category.isNotBlank()) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

private fun toPaisa(value: String): Long = try {
    BigDecimal(value).multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
} catch (_: Exception) { 0 }

private fun money(paisa: Long): String {
    val taka = BigDecimal(paisa).divide(BigDecimal(100))
    return "৳${NumberFormat.getNumberInstance(Locale("en", "BD")).format(taka)}"
}
