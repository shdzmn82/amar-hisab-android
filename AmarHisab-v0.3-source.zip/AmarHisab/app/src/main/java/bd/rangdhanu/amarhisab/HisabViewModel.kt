package bd.rangdhanu.amarhisab

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import bd.rangdhanu.amarhisab.data.DashboardSummary
import bd.rangdhanu.amarhisab.data.HisabDatabase
import bd.rangdhanu.amarhisab.data.Ledger
import bd.rangdhanu.amarhisab.data.MoneyTransaction
import bd.rangdhanu.amarhisab.data.TransactionType
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HisabViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = HisabDatabase.get(application).dao()

    val state = combine(dao.observeLedgers(), dao.observeTransactions()) { ledgers, transactions ->
        val ledgerOrder = listOf("PERSONAL", "SCHOOL", "COACHING", "PRIVATE_TUITION", "LOAN", "BANK")
        HisabUiState(
            ledgers = ledgers.sortedBy { ledgerOrder.indexOf(it.type).let { index -> if (index < 0) Int.MAX_VALUE else index } },
            transactions = transactions,
            summary = DashboardSummary(
                totalIncomePaisa = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPaisa },
                totalExpensePaisa = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPaisa }
            )
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HisabUiState())

    init {
        viewModelScope.launch {
            listOf(
                Ledger(name = "ব্যক্তিগত হিসাব", type = "PERSONAL"),
                Ledger(name = "রংধনু মডেল স্কুল", type = "SCHOOL"),
                Ledger(name = "কোচিং হিসাব", type = "COACHING"),
                Ledger(name = "ব্যক্তিগত প্রাইভেট", type = "PRIVATE_TUITION"),
                Ledger(name = "ধার দেওয়া ও নেওয়া", type = "LOAN"),
                Ledger(name = "ব্যাংক হিসাব", type = "BANK")
            ).forEach { ledger ->
                if (dao.ledgerCountByType(ledger.type) == 0) dao.insertLedger(ledger)
            }
        }
    }

    fun saveTransaction(id: Long, ledgerId: Long, type: TransactionType, amountPaisa: Long, category: String, note: String, occurredAt: Long) {
        if (amountPaisa <= 0 || category.isBlank()) return
        viewModelScope.launch {
            dao.saveTransaction(MoneyTransaction(id = id, ledgerId = ledgerId, type = type, amountPaisa = amountPaisa, category = category.trim(), note = note.trim(), occurredAt = occurredAt))
        }
    }

    fun deleteTransaction(id: Long) {
        if (id <= 0) return
        viewModelScope.launch { dao.deleteTransaction(id) }
    }
}

data class HisabUiState(
    val ledgers: List<Ledger> = emptyList(),
    val transactions: List<MoneyTransaction> = emptyList(),
    val summary: DashboardSummary = DashboardSummary()
)
