package bd.rangdhanu.amarhisab.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType { INCOME, EXPENSE }

@Entity(tableName = "ledgers")
data class Ledger(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val openingBalance: Double = 0.0
)

@Entity(tableName = "transactions")
data class MoneyTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ledgerId: Long,
    val type: TransactionType,
    val amountPaisa: Long,
    val category: String,
    val note: String,
    val occurredAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val roll: String,
    val className: String,
    val monthlyFeePaisa: Long
)

@Entity(tableName = "fee_payments")
data class FeePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val monthKey: String,
    val amountPaisa: Long,
    val paidAt: Long = System.currentTimeMillis()
)

data class DashboardSummary(
    val totalIncomePaisa: Long = 0,
    val totalExpensePaisa: Long = 0
) {
    val balancePaisa: Long get() = totalIncomePaisa - totalExpensePaisa
}
