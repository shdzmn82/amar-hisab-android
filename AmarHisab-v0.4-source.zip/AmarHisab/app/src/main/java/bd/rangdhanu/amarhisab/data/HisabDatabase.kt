package bd.rangdhanu.amarhisab.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

class DbConverters {
    @TypeConverter fun fromType(value: TransactionType): String = value.name
    @TypeConverter fun toType(value: String): TransactionType = TransactionType.valueOf(value)
}

@Database(entities = [Ledger::class, MoneyTransaction::class, Student::class, FeePayment::class], version = 2, exportSchema = true)
@TypeConverters(DbConverters::class)
abstract class HisabDatabase : RoomDatabase() {
    abstract fun dao(): HisabDao

    companion object {
        @Volatile private var instance: HisabDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `students` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `roll` TEXT NOT NULL, `className` TEXT NOT NULL, `monthlyFeePaisa` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `fee_payments` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `studentId` INTEGER NOT NULL, `monthKey` TEXT NOT NULL, `amountPaisa` INTEGER NOT NULL, `paidAt` INTEGER NOT NULL)")
            }
        }

        fun get(context: Context): HisabDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                HisabDatabase::class.java,
                "amar_hisab.db"
            ).addMigrations(MIGRATION_1_2).build().also { instance = it }
        }
    }
}
