package bd.rangdhanu.amarhisab.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HisabDao {
    @Query("SELECT * FROM ledgers ORDER BY id")
    fun observeLedgers(): Flow<List<Ledger>>

    @Query("SELECT * FROM transactions ORDER BY occurredAt DESC")
    fun observeTransactions(): Flow<List<MoneyTransaction>>

    @Query("SELECT * FROM students ORDER BY className, roll, name")
    fun observeStudents(): Flow<List<Student>>

    @Query("SELECT * FROM fee_payments ORDER BY paidAt DESC")
    fun observeFeePayments(): Flow<List<FeePayment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedger(ledger: Ledger): Long

    @Insert
    suspend fun insertTransaction(transaction: MoneyTransaction)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveTransaction(transaction: MoneyTransaction)

    @Query("DELETE FROM transactions WHERE id = :transactionId")
    suspend fun deleteTransaction(transactionId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveStudent(student: Student): Long

    @Insert
    suspend fun insertFeePayment(payment: FeePayment)

    @Query("SELECT COUNT(*) FROM ledgers")
    suspend fun ledgerCount(): Int

    @Query("SELECT COUNT(*) FROM ledgers WHERE type = :type")
    suspend fun ledgerCountByType(type: String): Int
}
