package bd.rangdhanu.amarhisab

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import bd.rangdhanu.amarhisab.data.DashboardSummary
import bd.rangdhanu.amarhisab.data.HisabDatabase
import bd.rangdhanu.amarhisab.data.Ledger
import bd.rangdhanu.amarhisab.data.MoneyTransaction
import bd.rangdhanu.amarhisab.data.TransactionType
import bd.rangdhanu.amarhisab.data.Student
import bd.rangdhanu.amarhisab.data.FeePayment
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HisabViewModel(application: Application) : AndroidViewModel(application) {
    private val db = HisabDatabase.get(application)
    private val dao = db.dao()

    val state = combine(dao.observeLedgers(), dao.observeTransactions(), dao.observeStudents(), dao.observeFeePayments()) { ledgers, transactions, students, payments ->
        val ledgerOrder = listOf("PERSONAL", "SCHOOL", "COACHING", "PRIVATE_TUITION", "LOAN", "BANK")
        HisabUiState(
            ledgers = ledgers.sortedBy { ledgerOrder.indexOf(it.type).let { index -> if (index < 0) Int.MAX_VALUE else index } },
            transactions = transactions,
            students = students,
            feePayments = payments,
            summary = DashboardSummary(
                totalIncomePaisa = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPaisa },
                totalExpensePaisa = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPaisa }
            )
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HisabUiState())

    init {
        viewModelScope.launch {
            listOf(
                Ledger(name = "ব্যক্তিগত হিসাব", type = "PERSONAL"),
                Ledger(name = "রংধনু মডেল স্কুল", type = "SCHOOL"),
                Ledger(name = "কোচিং হিসাব", type = "COACHING"),
                Ledger(name = "ব্যক্তিগত প্রাইভেট", type = "PRIVATE_TUITION"),
                Ledger(name = "ধার দেওয়া ও নেওয়া", type = "LOAN"),
                Ledger(name = "ব্যাংক হিসাব", type = "BANK")
            ).forEach { ledger ->
                if (dao.ledgerCountByType(ledger.type) == 0) dao.insertLedger(ledger)
            }
        }
    }

    fun saveTransaction(id: Long, ledgerId: Long, type: TransactionType, amountPaisa: Long, category: String, note: String, occurredAt: Long) {
        if (amountPaisa <= 0 || category.isBlank()) return
        viewModelScope.launch {
            dao.saveTransaction(MoneyTransaction(id = id, ledgerId = ledgerId, type = type, amountPaisa = amountPaisa, category = category.trim(), note = note.trim(), occurredAt = occurredAt))
        }
    }

    fun deleteTransaction(id: Long) {
        if (id <= 0) return
        viewModelScope.launch { dao.deleteTransaction(id) }
    }

    fun saveStudent(name: String, roll: String, className: String, monthlyFeePaisa: Long) {
        if (name.isBlank() || className.isBlank() || monthlyFeePaisa <= 0) return
        viewModelScope.launch { dao.saveStudent(Student(name = name.trim(), roll = roll.trim(), className = className.trim(), monthlyFeePaisa = monthlyFeePaisa)) }
    }

    fun receiveFee(student: Student, ledgerId: Long, amountPaisa: Long) {
        if (ledgerId <= 0 || amountPaisa <= 0) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date(now))
            db.withTransaction {
                dao.insertFeePayment(FeePayment(studentId = student.id, monthKey = month, amountPaisa = amountPaisa, paidAt = now))
                dao.saveTransaction(MoneyTransaction(ledgerId = ledgerId, type = TransactionType.INCOME, amountPaisa = amountPaisa, category = "শিক্ষার্থীর ফি", note = "${student.name} • ${student.className} • রোল ${student.roll}", occurredAt = now))
            }
        }
    }
}

data class HisabUiState(
    val ledgers: List<Ledger> = emptyList(),
    val transactions: List<MoneyTransaction> = emptyList(),
    val students: List<Student> = emptyList(),
    val feePayments: List<FeePayment> = emptyList(),
    val summary: DashboardSummary = DashboardSummary()
)
