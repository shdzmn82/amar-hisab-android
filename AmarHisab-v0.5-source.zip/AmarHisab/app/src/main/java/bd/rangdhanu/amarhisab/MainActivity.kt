package bd.rangdhanu.amarhisab

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import bd.rangdhanu.amarhisab.data.Ledger
import bd.rangdhanu.amarhisab.data.MoneyTransaction
import bd.rangdhanu.amarhisab.data.TransactionType
import bd.rangdhanu.amarhisab.data.Student
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF176B50), background = Color(0xFFF6FBF8))) {
                HisabApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HisabApp(vm: HisabViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<MoneyTransaction?>(null) }
    var showEntry by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<MoneyTransaction?>(null) }
    var selectedLedgerId by remember { mutableStateOf<Long?>(null) }
    var showStudentDialog by remember { mutableStateOf(false) }
    var payingStudent by remember { mutableStateOf<Student?>(null) }
    var page by remember { mutableStateOf("HOME") }
    var studentQuery by remember { mutableStateOf("") }

    val currentMonthEntries = state.transactions.filter { isCurrentMonth(it.occurredAt) }
    val monthIncome = currentMonthEntries.filter { it.type == TransactionType.INCOME }.sumOf { it.amountPaisa }
    val monthExpense = currentMonthEntries.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountPaisa }
    val visibleTransactions = selectedLedgerId?.let { id -> state.transactions.filter { it.ledgerId == id } } ?: state.transactions
    val visibleStudents = state.students.filter {
        studentQuery.isBlank() || it.name.contains(studentQuery, true) ||
            it.roll.contains(studentQuery, true) || it.className.contains(studentQuery, true)
    }
    val expectedFee = state.students.sumOf { it.monthlyFeePaisa }
    val collectedFee = state.feePayments.filter { it.monthKey == monthKey() }.sumOf { it.amountPaisa }

    Scaffold(
        topBar = { TopAppBar(title = { Text("আমার হিসাব", fontWeight = FontWeight.Bold) }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (page == "FEES") showStudentDialog = true
                    else { editing = null; showEntry = true }
                },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text(if (page == "FEES") "শিক্ষার্থী" else "নতুন এন্ট্রি") }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PageSelector(page) { page = it } }

            if (page == "HOME") {
                item { SummaryCard(state.summary.balancePaisa, monthIncome, monthExpense) }
                item { Heading("হিসাবখাতা") }
                items(state.ledgers, key = { it.id }) { ledger ->
                    val entries = state.transactions.filter { it.ledgerId == ledger.id }
                    val balance = entries.sumOf { if (it.type == TransactionType.INCOME) it.amountPaisa else -it.amountPaisa }
                    LedgerCard(ledger, balance, entries.size, selectedLedgerId == ledger.id) {
                        selectedLedgerId = if (selectedLedgerId == ledger.id) null else ledger.id
                        page = "TRANSACTIONS"
                    }
                }
            }

            if (page == "FEES") {
                item { FeeSummaryCard(expectedFee, collectedFee, (expectedFee - collectedFee).coerceAtLeast(0)) }
                item {
                    OutlinedTextField(
                        value = studentQuery,
                        onValueChange = { studentQuery = it },
                        label = { Text("নাম, রোল বা শ্রেণি দিয়ে খুঁজুন") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Heading("শিক্ষার্থী ফি")
                        TextButton(onClick = { showStudentDialog = true }) { Text("+ শিক্ষার্থী") }
                    }
                }
                if (visibleStudents.isEmpty()) item { Text("কোনো শিক্ষার্থী পাওয়া যায়নি।") }
                items(visibleStudents, key = { "student-${it.id}" }) { student ->
                    val paid = state.feePayments.filter { it.studentId == student.id && it.monthKey == monthKey() }.sumOf { it.amountPaisa }
                    StudentCard(student, paid, (student.monthlyFeePaisa - paid).coerceAtLeast(0)) { payingStudent = student }
                }
            }

            if (page == "TRANSACTIONS") {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Heading(selectedLedgerId?.let { id -> state.ledgers.firstOrNull { it.id == id }?.name } ?: "সকল লেনদেন")
                        if (selectedLedgerId != null) TextButton(onClick = { selectedLedgerId = null }) { Text("সব দেখুন") }
                    }
                }
                if (visibleTransactions.isEmpty()) item { Text("এই হিসাবখাতায় কোনো লেনদেন নেই।") }
                items(visibleTransactions.take(100), key = { it.id }) { tx ->
                    TransactionCard(
                        tx,
                        state.ledgers.firstOrNull { it.id == tx.ledgerId }?.name ?: "হিসাবখাতা",
                        onEdit = { editing = tx; showEntry = true },
                        onDelete = { deleting = tx }
                    )
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }

    if (showEntry && state.ledgers.isNotEmpty()) {
        EntryDialog(state.ledgers, editing, onDismiss = { showEntry = false; editing = null }) {
                id, ledgerId, type, amount, category, note, date ->
            vm.saveTransaction(id, ledgerId, type, amount, category, note, date)
            showEntry = false
            editing = null
        }
    }

    if (showStudentDialog) {
        StudentDialog(onDismiss = { showStudentDialog = false }) { name, roll, className, fee ->
            vm.saveStudent(name, roll, className, fee)
            showStudentDialog = false
        }
    }

    payingStudent?.let { student ->
        val paid = state.feePayments.filter { it.studentId == student.id && it.monthKey == monthKey() }.sumOf { it.amountPaisa }
        val due = (student.monthlyFeePaisa - paid).coerceAtLeast(0)
        FeeDialog(student, due, state.ledgers, onDismiss = { payingStudent = null }) { ledgerId, amount ->
            vm.receiveFee(student, ledgerId, amount)
            payingStudent = null
        }
    }

    deleting?.let { tx ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("লেনদেন মুছবেন?") },
            text = { Text("${tx.category} — ${money(tx.amountPaisa)} স্থায়ীভাবে মুছে যাবে।") },
            confirmButton = {
                TextButton(onClick = { vm.deleteTransaction(tx.id); deleting = null }) {
                    Text("মুছুন", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("বাতিল") } }
        )
    }
}

@Composable private fun Heading(text: String) = Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

@Composable
private fun PageSelector(page: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(selected = page == "HOME", onClick = { onSelect("HOME") }, label = { Text("হোম") })
        FilterChip(selected = page == "FEES", onClick = { onSelect("FEES") }, label = { Text("শিক্ষার্থী ফি") })
        FilterChip(selected = page == "TRANSACTIONS", onClick = { onSelect("TRANSACTIONS") }, label = { Text("লেনদেন") })
    }
}

@Composable
private fun FeeSummaryCard(expected: Long, collected: Long, due: Long) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("চলতি মাসের ফি", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("নির্ধারিত\n${money(expected)}")
                Text("আদায়\n${money(collected)}", color = Color(0xFF176B50))
                Text("বকেয়া\n${money(due)}", color = if (due > 0) Color(0xFFB3261E) else Color(0xFF176B50))
            }
        }
    }
}

@Composable
private fun SummaryCard(balance: Long, monthIncome: Long, monthExpense: Long) {
    Card(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("সর্বমোট বর্তমান ব্যালেন্স", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(money(balance), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("এই মাসের আয়\n${money(monthIncome)}", color = Color(0xFF176B50))
                Text("এই মাসের ব্যয়\n${money(monthExpense)}", color = Color(0xFFB3261E))
            }
        }
    }
}

@Composable
private fun LedgerCard(ledger: Ledger, balance: Long, count: Int, selected: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(
        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    )) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(ledger.name, fontWeight = FontWeight.SemiBold)
                Text("$count টি লেনদেন", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(money(balance), fontWeight = FontWeight.Bold, color = if (balance >= 0) Color(0xFF176B50) else Color(0xFFB3261E))
        }
    }
}

@Composable
private fun TransactionCard(tx: MoneyTransaction, ledgerName: String, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(tx.category, fontWeight = FontWeight.Medium)
                Text("$ledgerName • ${dateText(tx.occurredAt)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (tx.note.isNotBlank()) Text(tx.note)
            }
            Column {
                Text(
                    (if (tx.type == TransactionType.INCOME) "+ " else "− ") + money(tx.amountPaisa),
                    color = if (tx.type == TransactionType.INCOME) Color(0xFF176B50) else Color(0xFFB3261E),
                    fontWeight = FontWeight.SemiBold
                )
                Row {
                    IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "সম্পাদনা") }
                    IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "মুছুন", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
}

@Composable
private fun StudentCard(student: Student, paid: Long, due: Long, onPay: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(student.name, fontWeight = FontWeight.SemiBold)
                    Text("${student.className} • রোল ${student.roll}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("বকেয়া ${money(due)}", color = if (due > 0) Color(0xFFB3261E) else Color(0xFF176B50))
            }
            Text("এই মাসে পরিশোধ: ${money(paid)} / ${money(student.monthlyFeePaisa)}")
            TextButton(onClick = onPay, enabled = due > 0) { Text(if (due > 0) "ফি গ্রহণ" else "পরিশোধ সম্পন্ন") }
        }
    }
}

@Composable
private fun StudentDialog(onDismiss: () -> Unit, onSave: (String, String, String, Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var roll by remember { mutableStateOf("") }
    var className by remember { mutableStateOf("") }
    var fee by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন শিক্ষার্থী") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("শিক্ষার্থীর নাম") }, singleLine = true)
            OutlinedTextField(roll, { roll = it }, label = { Text("রোল") }, singleLine = true)
            OutlinedTextField(className, { className = it }, label = { Text("শ্রেণি/ব্যাচ") }, singleLine = true)
            OutlinedTextField(fee, { fee = it.filter(Char::isDigit) }, label = { Text("মাসিক ফি") }, singleLine = true)
        } },
        confirmButton = { TextButton(onClick = { onSave(name, roll, className, toPaisa(fee)) }, enabled = name.isNotBlank() && className.isNotBlank() && toPaisa(fee) > 0) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun FeeDialog(student: Student, duePaisa: Long, ledgers: List<Ledger>, onDismiss: () -> Unit, onSave: (Long, Long) -> Unit) {
    var amount by remember(student.id, duePaisa) { mutableStateOf(paisaInput(duePaisa)) }
    var ledgerId by remember(student.id) { mutableLongStateOf(ledgers.firstOrNull { it.type == "SCHOOL" }?.id ?: ledgers.first().id) }
    var menuOpen by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${student.name}—ফি গ্রহণ") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("পরিমাণ") }, singleLine = true)
            Box {
                OutlinedButton({ menuOpen = true }, Modifier.fillMaxWidth()) { Text(ledgers.first { it.id == ledgerId }.name) }
                DropdownMenu(menuOpen, { menuOpen = false }) {
                    ledgers.forEach { ledger -> DropdownMenuItem({ Text(ledger.name) }, { ledgerId = ledger.id; menuOpen = false }) }
                }
            }
            Text("ফি গ্রহণ করলে একই পরিমাণ নির্বাচিত হিসাবখাতায় আয় হিসেবে যোগ হবে।", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = { onSave(ledgerId, toPaisa(amount)) }, enabled = toPaisa(amount) > 0) { Text("ফি গ্রহণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun EntryDialog(
    ledgers: List<Ledger>, existing: MoneyTransaction?, onDismiss: () -> Unit,
    onSave: (Long, Long, TransactionType, Long, String, String, Long) -> Unit
) {
    val context = LocalContext.current
    var ledgerId by remember(existing?.id) { mutableLongStateOf(existing?.ledgerId ?: ledgers.first().id) }
    var amount by remember(existing?.id) { mutableStateOf(existing?.let { paisaInput(it.amountPaisa) } ?: "") }
    var category by remember(existing?.id) { mutableStateOf(existing?.category ?: "") }
    var note by remember(existing?.id) { mutableStateOf(existing?.note ?: "") }
    var type by remember(existing?.id) { mutableStateOf(existing?.type ?: TransactionType.EXPENSE) }
    var occurredAt by remember(existing?.id) { mutableLongStateOf(existing?.occurredAt ?: System.currentTimeMillis()) }
    var menuOpen by remember { mutableStateOf(false) }
    val categories = if (type == TransactionType.INCOME)
        listOf("বেতন", "শিক্ষার্থীর ফি", "কোচিং ফি", "ব্যবসা", "উপহার", "অন্যান্য আয়")
    else listOf("বাজার", "যাতায়াত", "শিক্ষা", "চিকিৎসা", "বেতন", "বিল", "অন্যান্য ব্যয়")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "নতুন আয়–ব্যয়" else "লেনদেন সম্পাদনা") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == TransactionType.INCOME, { type = TransactionType.INCOME; category = "" }, label = { Text("আয়") })
                    FilterChip(type == TransactionType.EXPENSE, { type = TransactionType.EXPENSE; category = "" }, label = { Text("ব্যয়") })
                }
                Box {
                    OutlinedButton({ menuOpen = true }, Modifier.fillMaxWidth()) {
                        Text(ledgers.firstOrNull { it.id == ledgerId }?.name ?: "হিসাবখাতা নির্বাচন")
                    }
                    DropdownMenu(menuOpen, { menuOpen = false }) {
                        ledgers.forEach { ledger ->
                            DropdownMenuItem({ Text(ledger.name) }, { ledgerId = ledger.id; menuOpen = false })
                        }
                    }
                }
                OutlinedTextField(amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("পরিমাণ") }, singleLine = true)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    categories.forEach { item -> FilterChip(category == item, { category = item }, label = { Text(item) }) }
                }
                OutlinedTextField(category, { category = it }, label = { Text("খাত/ক্যাটাগরি") }, singleLine = true)
                OutlinedButton(onClick = {
                    val cal = Calendar.getInstance().apply { timeInMillis = occurredAt }
                    DatePickerDialog(context, { _, y, m, d ->
                        occurredAt = Calendar.getInstance().apply {
                            set(y, m, d, 12, 0, 0); set(Calendar.MILLISECOND, 0)
                        }.timeInMillis
                    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                }, modifier = Modifier.fillMaxWidth()) { Text("তারিখ: ${dateText(occurredAt)}") }
                OutlinedTextField(note, { note = it }, label = { Text("বিবরণ (ঐচ্ছিক)") })
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(existing?.id ?: 0, ledgerId, type, toPaisa(amount), category, note, occurredAt) },
                enabled = toPaisa(amount) > 0 && category.isNotBlank()
            ) { Text("সংরক্ষণ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

private fun toPaisa(value: String): Long = try {
    BigDecimal(value).multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
} catch (_: Exception) { 0 }

private fun paisaInput(paisa: Long) = BigDecimal(paisa).divide(BigDecimal(100)).stripTrailingZeros().toPlainString()

private fun money(paisa: Long): String = "৳" + NumberFormat.getNumberInstance(Locale("en", "BD")).format(BigDecimal(paisa).divide(BigDecimal(100)))

private fun dateText(timestamp: Long): String = SimpleDateFormat("dd MMM yyyy", Locale("bn", "BD")).format(Date(timestamp))

private fun isCurrentMonth(timestamp: Long): Boolean {
    val now = Calendar.getInstance()
    val date = Calendar.getInstance().apply { timeInMillis = timestamp }
    return now.get(Calendar.YEAR) == date.get(Calendar.YEAR) &&
        now.get(Calendar.MONTH) == date.get(Calendar.MONTH)
}

private fun monthKey(): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
