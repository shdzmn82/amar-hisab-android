package bd.rangdhanu.amarhisab

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

class AppLockManager(context: Context) {
    private val prefs = context.getSharedPreferences("app_lock", Context.MODE_PRIVATE)

    fun isPinEnabled(): Boolean = prefs.contains(KEY_HASH) && prefs.contains(KEY_SALT)

    fun isBiometricEnabled(): Boolean = isPinEnabled() && prefs.getBoolean(KEY_BIOMETRIC, false)

    fun save(pin: String, biometric: Boolean) {
        require(pin.length in 4..8 && pin.all(Char::isDigit)) { "PIN অবশ্যই ৪–৮ সংখ্যার হতে হবে" }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString(KEY_SALT, encode(salt))
            .putString(KEY_HASH, encode(hash(pin, salt)))
            .putBoolean(KEY_BIOMETRIC, biometric)
            .apply()
    }

    fun verify(pin: String): Boolean {
        val salt = prefs.getString(KEY_SALT, null)?.let(::decode) ?: return false
        val expected = prefs.getString(KEY_HASH, null)?.let(::decode) ?: return false
        return MessageDigest.isEqual(expected, hash(pin, salt))
    }

    fun clear() = prefs.edit().clear().apply()

    private fun hash(pin: String, salt: ByteArray): ByteArray {
        var value = salt + pin.toByteArray(Charsets.UTF_8)
        repeat(20_000) { value = MessageDigest.getInstance("SHA-256").digest(value) }
        return value
    }

    private fun encode(value: ByteArray) = Base64.encodeToString(value, Base64.NO_WRAP)
    private fun decode(value: String) = Base64.decode(value, Base64.NO_WRAP)

    private companion object {
        const val KEY_HASH = "pin_hash"
        const val KEY_SALT = "pin_salt"
        const val KEY_BIOMETRIC = "biometric"
    }
}
