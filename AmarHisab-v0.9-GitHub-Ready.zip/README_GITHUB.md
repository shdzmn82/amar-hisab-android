# AmarHisab v0.9.0 — GitHub Ready

This repository is prepared for GitHub Actions Android APK compilation.

## Upload to GitHub

Upload the **contents of this folder** to the root of a GitHub repository (do not create another `AmarHisab/` folder inside the repository).

The repository root should contain:

- `app/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `gradle.properties`
- `.github/workflows/build-apk.yml`

## Build on GitHub

1. Push the files to the `main` branch.
2. Open **Actions** in GitHub.
3. Select **Build AmarHisab APK**.
4. A push or pull request to `main` will start the workflow automatically.
5. You can also select **Run workflow** for a manual build.
6. After the job succeeds, open the workflow run and download the artifact named:
   `AmarHisab-v0.9.0-debug`

The workflow uses JDK 17 and Gradle 8.9 and runs `assembleDebug`.

## Important

No signing key is stored in this GitHub-ready package. Android's normal debug signing is used for the debug APK. For a Play Store/release build, use a separate private signing key stored in GitHub Actions Secrets.
