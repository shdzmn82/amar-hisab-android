# আমার হিসাব — Android App

বাংলা ভাষায় ব্যক্তিগত, স্কুল, কোচিং, ধার-পাওনা ও ব্যাংক হিসাব রাখার অফলাইন Android অ্যাপ।

## বর্তমান সংস্করণ (0.9.0)

- বাংলা Dashboard
- পাঁচটি প্রাথমিক হিসাবখাতা
- আয় ও ব্যয় এন্ট্রি
- Room offline database
- মোট আয়, ব্যয় ও বর্তমান ব্যালেন্স
- সাম্প্রতিক লেনদেন
- Android cloud backup configuration
- Java ও Kotlin JVM target 17 (GitHub Actions build compatibility)
- এন্ট্রির সময় হিসাবখাতা নির্বাচন
- লেনদেনের তারিখ নির্বাচন ও প্রস্তুত ক্যাটাগরি
- প্রতিটি হিসাবখাতার আলাদা ব্যালেন্স ও লেনদেন সংখ্যা
- লেনদেন সম্পাদনা এবং নিশ্চিতকরণসহ মুছে ফেলা
- ধারাবাহিক পরীক্ষামূলক APK update-এর জন্য স্থায়ী development signing key
- কোচিং হিসাবের পরে আলাদা `ব্যক্তিগত প্রাইভেট` হিসাবখাতা
- হিসাবখাতায় ট্যাপ করে সংশ্লিষ্ট লেনদেন ফিল্টার
- বর্তমান মাসের আয় ও ব্যয়ের আলাদা সারাংশ
- শিক্ষার্থী, রোল, শ্রেণি/ব্যাচ ও মাসিক ফি সংরক্ষণ
- চলতি মাসের পরিশোধ ও বকেয়া হিসাব
- ফি গ্রহণের সঙ্গে নির্বাচিত হিসাবখাতায় স্বয়ংক্রিয় আয় এন্ট্রি
- v1 থেকে v2 নিরাপদ Room database migration
- আলাদা হোম, শিক্ষার্থী ফি ও লেনদেন পেজ
- শিক্ষার্থীর নাম, রোল বা শ্রেণি দিয়ে অনুসন্ধান
- চলতি মাসের মোট নির্ধারিত ফি, আদায় ও বকেয়া সারাংশ
- নতুন Android launcher icon
- ধার দেওয়া ও নেওয়ার রেকর্ড, ফোন ও পরিশোধের তারিখ
- মোট পাওনা ও মোট দেনার সারাংশ
- আংশিক/পূর্ণ নিষ্পত্তি এবং স্বয়ংক্রিয় আয়–ব্যয় এন্ট্রি
- v2 থেকে v3 নিরাপদ Room database migration
- একাধিক ব্যাংক হিসাব ও প্রারম্ভিক ব্যালেন্স
- নগদ খাতা থেকে ব্যাংকে জমা এবং ব্যাংক থেকে নগদ উত্তোলন
- ব্যাংকসহ সর্বমোট বর্তমান ব্যালেন্স
- চলতি মাসের খাতভিত্তিক বাজেট, অগ্রগতি ও সীমা অতিক্রম সতর্কতা
- v3 থেকে v4 নিরাপদ Room database migration
- চলতি মাস বাদ দিয়ে আগের সর্বোচ্চ ১২ সম্পূর্ণ মাস থেকে স্বয়ংক্রিয় বাজেট
- ক্যাটাগরিভিত্তিক ০–৫০% ব্যয় সংকোচন হার
- এককালীন/অস্বাভাবিক ব্যয় বাজেট গণনা থেকে বাদ
- ব্যয় এন্ট্রিতে বাজেট, চলতি ব্যয়, ব্যয়যোগ্য সীমা ও projected warning
- v4 থেকে v5 নিরাপদ Room database migration
- CSV transaction export using Android document picker
- PDF transaction report export
- Encrypted AES-GCM backup (`.ahb`) protected by a user password
- Backup restore with version validation and a local pre-restore database safety copy
- Room database migrated from v5 to v6 without schema changes

## চালানোর নিয়ম

1. Android Studio-তে `AmarHisab` ফোল্ডারটি Open করুন।
2. Gradle Sync শেষ হতে দিন।
3. Android ফোনে USB debugging চালু করে Run চাপুন, অথবা Build > Build APK(s) ব্যবহার করুন।

ন্যূনতম Android 8.0 (API 26)।

GitHub দিয়ে APK তৈরির জন্য `README_GITHUB.md` অনুসরণ করুন। প্রকল্পে প্রস্তুত
GitHub Actions workflow যুক্ত আছে।

## পরবর্তী সংস্করণ

- হিসাবখাতা নির্বাচন করে এন্ট্রি
- ফি ও শিক্ষার্থী ব্যবস্থাপনা
- ধার/পাওনা কিস্তি
- ব্যাংক হিসাব
- বাজেট ও ব্যয় সতর্কতা
- CSV/PDF রসিদ ও রিপোর্ট
- PIN/Fingerprint
- ব্যবহারকারী-নিয়ন্ত্রিত Google Drive backup/restore


